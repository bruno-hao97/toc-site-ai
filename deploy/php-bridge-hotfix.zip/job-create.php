<?php
declare(strict_types=1);

require __DIR__ . '/bootstrap.php';
require __DIR__ . '/gommo.php';
require __DIR__ . '/load-job-status-helpers.php';

// #region agent log
function debug_session_log_91a0f9(array $payload): void
{
    $line = json_encode(array_merge([
        'sessionId' => '91a0f9',
        'timestamp' => (int) round(microtime(true) * 1000),
    ], $payload), JSON_UNESCAPED_UNICODE) . "\n";
    @file_put_contents(__DIR__ . '/debug-91a0f9.log', $line, FILE_APPEND);
}
debug_session_log_91a0f9([
    'hypothesisId' => 'A',
    'location' => 'job-create.php:boot',
    'message' => 'job-create boot',
    'data' => [
        'hasNormalize' => function_exists('normalize_stored_job_status'),
        'hasHelpersFile' => is_file(__DIR__ . '/job-status-helpers.php'),
        'gommoMtime' => @filemtime(__DIR__ . '/gommo.php') ?: null,
    ],
]);
// #endregion

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_out(405, ['success' => false, 'message' => 'Method not allowed']);
}

[$pdo, $user] = require_bearer_user();
$body = read_json_body();

$type = trim((string) ($body['type'] ?? 'image'));
$modelId = trim((string) ($body['modelId'] ?? $body['model_id'] ?? ''));
$fields = $body['fields'] ?? [];
if (!is_array($fields)) {
    $fields = [];
}

if ($type === '' || !preg_match('/^[a-z0-9-]+$/', $type)) {
    json_out(400, ['success' => false, 'message' => 'job type không hợp lệ']);
}
if ($modelId === '') {
    json_out(400, ['success' => false, 'message' => 'Thiếu modelId']);
}

// Giá từ catalog Gommo (mode/resolution) — không tin costCredits từ client.
$cost = resolve_job_cost($type, $modelId, $fields);
if ($cost < 1) {
    json_out(400, ['success' => false, 'message' => 'Không xác định được giá model']);
}

$jobId = uuid_v4();

try {
    $pdo->beginTransaction();
    charge_user_credits($pdo, (string) $user['id'], $cost);

    $path = '/ai/jobs/' . rawurlencode($type) . '/' . rawurlencode($modelId);
    $envelope = gommo_post_form($path, $fields);

    $providerJobId = extract_provider_job_id($envelope);
    $resultUrl = extract_result_url($envelope);
    $status = normalize_stored_job_status(extract_status($envelope), $resultUrl);
    if ($status === 'processing' && !$providerJobId && !$resultUrl) {
        $status = 'pending';
    }

    $prompt = trim((string) ($fields['prompt'] ?? ''));
    $meta = [
        'ratio' => isset($fields['ratio']) ? (string) $fields['ratio'] : null,
        'resolution' => isset($fields['resolution']) ? (string) $fields['resolution'] : null,
        'mode' => isset($fields['mode']) ? (string) $fields['mode'] : null,
    ];
    $meta = array_filter($meta, static function ($v) {
        return $v !== null && $v !== '';
    });
    $metaJson = $meta === [] ? null : json_encode($meta, JSON_UNESCAPED_UNICODE);

    // Create đã fail ngay → hoàn credit trong cùng transaction.
    $alreadyFailed = !$resultUrl && is_job_failed_status($status);
    if ($alreadyFailed) {
        refund_user_credits($pdo, (string) $user['id'], $cost);
        $status = $status !== '' && $status !== 'processing' ? $status : 'FAILED';
    }

    $pdo->prepare(
        'INSERT INTO platform_jobs (id, user_id, job_type, model_id, provider, provider_job_id, status, result_url, prompt, meta_json, cost_credits)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    )->execute([
        $jobId,
        $user['id'],
        $type,
        $modelId,
        'vmedia',
        $providerJobId,
        $status,
        $resultUrl,
        $prompt !== '' ? $prompt : null,
        $metaJson,
        $cost,
    ]);

    if ($alreadyFailed) {
        try {
            $pdo->prepare(
                'UPDATE platform_jobs SET refunded_at = CURRENT_TIMESTAMP WHERE id = ? AND refunded_at IS NULL'
            )->execute([$jobId]);
        } catch (Throwable $ignored) {
            // Cột refunded_at có thể chưa migrate — bỏ qua.
        }
    }

    $pdo->commit();
    $freshUser = find_user_by_id($pdo, (string) $user['id']);

    json_out(201, [
        'success' => true,
        'data' => [
            'platformJobId' => $jobId,
            'costCredits' => $cost,
            'credits' => (int) (($freshUser ?: $user)['credits']),
            'envelope' => $envelope,
            'bridgeVersion' => '2026-07-20-hotfix1',
        ],
    ]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    // #region agent log
    debug_session_log_91a0f9([
        'hypothesisId' => 'A',
        'location' => 'job-create.php:catch',
        'message' => 'job-create failed',
        'data' => [
            'error' => $e->getMessage(),
            'hasNormalize' => function_exists('normalize_stored_job_status'),
        ],
    ]);
    // #endregion
    json_out(500, ['success' => false, 'message' => 'Tạo job thất bại: ' . $e->getMessage()]);
}
